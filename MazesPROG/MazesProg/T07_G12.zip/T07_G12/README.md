# MazesPROG

T07_G12
GROUP MEMBERS:
- Afonso Pinto up202008014
- Eduardo Silva up202005283

PROGRAM DEVELOPMENT STATE:
- All objectives were accomplished besides a problem with the scoreboard
MAIN DIFFICULTIES:
- The main difficulty was to find a way to locate the player in a .txt file and to get the leaderboard working.